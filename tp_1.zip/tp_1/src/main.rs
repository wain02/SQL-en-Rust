mod insert;
mod delete;
mod update;
mod parciar;
mod select;
mod sql_predicate;


use csv::{Reader, Writer};
use std::error::Error;

//use csv::Writer;
use std::fs::OpenOptions;
use std::io;

use std::fs::File;
use std::io::{BufRead, BufReader, Write};

//#[derive(Debug)]

// struct InfoTabla {
//     id: String,
//     id_cliente: String,
//     producto: String,
//     cantidad: String,
// }

// struct InstruccionBuilder {
//     consulta_sql: Vec<String>,
//     seleccion: Vec<String>, //Vec<String>
//     tabla: String,
// }

// enum Columnas {
//     Id_cleinte,
//     Nombre,
//     Npellido,
//     Email,
//     Id_producto,
//     Producto,
//     Cantidad,
// }

// enum Consulta {
//     Select,
//     Insert,
//     Delete,
//     Update,
// }

// impl InfoTabla {
//     pub fn new(id: String, id_cliente: String, producto: String, cantidad: String) -> Self {
//         InfoTabla {
//             id,
//             id_cliente,
//             producto,
//             cantidad,
//         }
//     }

//     /*pub fn seleccionar(parts: Vec<Str>) -> bool {
//         if parts.contains("*"){
//             println!("Your id is {} ", self.id);
//             println!("Your id_cliente is {} ", self.id_cliente);
//             println!("Your producto is {} ", self.producto);
//             println!("Your cantidad is {} ", self.cantidad);

//         }else{
//             println!("mal ahi chango");
//         }
//         true;
//     }*/
//     //pub fn insertar(wtr: Writer) -> bool {

//     //}
//     //pub fn borrar() -> bool {

//     //}
//     //pub fn actualizar() -> bool {

//     //}
//     //pub fn seleccionar() -> bool {

//     //}

//     // Devuelve el módulo del vector representado por la coordenada
//     //pub fn modulo(&self) -> f32 {
//     //  let cuadrado = (self.x * self.x) + (self.y * self.y);
//     //  (cuadrado as f32).sqrt()
//     //}
// }
/*
impl Update{
    pub fn new(consulta_sql: String, seleccion: String, tabla: String) -> Self {

        Update { consulta_sql, seleccion, tabla}
    }

    pub fn update(&self) -> String {
        //let cuadrado = (self.x * self.x) + (self.y * self.y);
        //(cuadrado as f32).sqrt();
        write_csv();

        String::from("messi")
    }

}*/
// impl InstruccionBuilder {
//     pub fn new(consulta_sql: Vec<String>, seleccion: Vec<String>, tabla: String) -> Self {
//         InstruccionBuilder {
//             consulta_sql,
//             seleccion,
//             tabla,
//         }
//     }

//     pub fn select(&mut self) -> String {
//         //let cuadrado = (self.x * self.x) + (self.y * self.y);
//         //(cuadrado as f32).sqrt();
//         //leer_csv(&self.seleccion, &self.tabla);
//         String::from("messi")
//     }

//     pub fn insert(&self) -> String {
//         //let cuadrado = (self.x * self.x) + (self.y * self.y);
//         //(cuadrado as f32).sqrt();
//         String::from("messi")
//     }

//     pub fn update(&self) -> String {
//         //let cuadrado = (self.x * self.x) + (self.y * self.y);
//         //(cuadrado as f32).sqrt();
//         //write_csv();

//         String::from("messi")
//     }

//     pub fn delete(&self) -> String {
//         //let cuadrado = (self.x * self.x) + (self.y * self.y);
//         //(cuadrado as f32).sqrt();
//         String::from("messi")
//     }
// }

use std::collections::HashMap;
//#[derive(Debug)]
// struct Update {
//     tabla: String,
//     insertar: HashMap<String,String>,
//     filtro: HashMap<String,String>,
// }

// impl Update {
//     fn area(&self) -> u32 {
//         self.width * self.height
//     }
// }

// struct Delete {
//     tabla: String,
//     eliminar: HashMap<String,String>,
    
// }

// impl Delete {
//     fn area(&self) -> u32 {
//         self.width * self.height
//     }
// }

use std::{fs, io::BufWriter};

/*fn delete_csv(delete_csv: Vec<&str>) -> io::Result<()> {
    let palabra = delete_csv[1].replace("'", "");

    println!("{}", palabra);
    let input = BufReader::new(fs::File::open("ordenes.csv")?);
    let mut archivo_copia = BufWriter::new(fs::File::create("archivo_copia.csv")?);
    for (i, line) in input.lines().enumerate() {
        let line = line?;

        if !line.contains(&palabra.to_string()) {
            writeln!(archivo_copia, "{line}")?;
        }
    }
    fs::rename("archivo_copia.csv", "ordenes.csv")?;
    Ok(())
}*/

//fn update_csv(datos_ingresar: Vec<&str>, filtro: Vec<&str>) -> io::Result<()> {
/*fn update_csv(struct_update: Update) -> io::Result<()> {
    //let palabra = delete_csv[1].replace("'","");
    
    // let mut p = String::from(",");
    // p.push_str(filtro[1]);
    // p.push_str(",");
    let mut archivo = struct_update.tabla;
    let mut contador_columnas_filtro = 0;
    let mut contador_columnas_insertar = 0;

    //println!("{}", palabra);
    let mut header = String::new();
    let mut input = BufReader::new(fs::File::open("ordenes.csv")?);
    input.read_line(&mut header)?;
    let header_vecto: Vec<&str> = header.trim().split(",").collect();
    // for (clave,valor) in &struct_update.filtro{
    //     for clave.to_string() ==
    //     println!("{} -> {}", clave, valor);
    // }
    println!("-----------------------------------");
    //println!("{}",header_vecto[contador_columnas_filtro]);
    //println!("{:?}",struct_update.filtro.get_key_value());
    // while  header_vecto[contador_columnas_filtro] != struct_update.filtro.get_key_value(){
    //     contador_columnas_filtro +=1
    // }
    //println!("Header: {}", header.trim());

    let mut archivo_copia = BufWriter::new(fs::File::create("archivo_copia.csv")?);
    for (i, line) in input.lines().enumerate() {
        let line = line?;
        if i==0{
            let columnas_csv: Vec<&str> = line.trim().split(",").collect();
        }
        
        // if columnas_csv.contains(struct_update.insertar.get_key_value()){

        // }
        println!("{}", line);
        let mut contador = 0; 
        
        
        // if line.contains(&p.to_string()){
        //     println!("mesiiiiiii");
        // }
        /*if !line.contains(&palabra.to_string()){
            writeln!(archivo_copia, "{line}")?;
        }*/
    }
    //fs::rename("archivo_copia.csv", "ordenes.csv")?;
    Ok(())
}*/

/*pub fn write_csv(insert: Vec<&str>) {
    let mut file = OpenOptions::new()
        .write(true)
        .append(true)
        .open("ordenes.csv")
        .unwrap();

    let mut wtr = csv::Writer::from_writer(file);
    wtr.write_record(&insert);
    
} */

// fn leer_csv(seleccion: &String, tabla: &String) {
//     seleccion.to_string();
//     //println!("{}", seleccion);
//     //println!("{}", tabla);
//     let file_name = tabla;
//     let result = Reader::from_path(file_name);
//     if result.is_err() {
//         println!("No pudo leer el csv");
//         std::process::exit(9);
//     }
//     let mut my_reader = result.unwrap();

//     for record in my_reader.records() {
//         let data = record.unwrap();
//         let info: InfoTabla = InfoTabla::new(
//             data.get(0).unwrap().to_string(),
//             data.get(1).unwrap().to_string(),
//             data.get(2).unwrap().to_string(),
//             data.get(3).unwrap().to_string(),
//         );

//         if seleccion == "*" {
//             println!("Your id is {} ", info.id);
//             println!("Your id_cliente is {} ", info.id_cliente);
//             println!("Your producto is {} ", info.producto);
//             println!("Your cantidad is {} ", info.cantidad);
//         } else {
//             println!("messi");
//         }
//         /*println!("Your id is {} ", info.id);
//         println!("Your id_cliente is {} ", info.id_cliente);
//         println!("Your producto is {} ", info.producto);
//         println!("Your cantidad is {} ", info.cantidad);*/
//     }
// }
// fn hashmap_creator(arreglo: Vec<&str>) ->HashMap::<String, String> {
    
//     let mut hashmap: HashMap<String, String> =  HashMap::<String, String>::new();
//     let mut contador = 0 ;
//     let lonngitud_arreglo = arreglo.len();
//     while contador != lonngitud_arreglo {
//         let mut clave = arreglo[contador];
//         contador += 1; //para ir al valor
//         let mut valor = arreglo[contador];
//         hashmap.insert(clave.to_string(), valor.to_string());
//         contador += 1;
//     };
//     //println!("{:#?}", hashmap);
//     hashmap
// }
// fn posicion_columna_csv(columna: String, tabla: String) -> usize {
//     // La idea en esta función es que devuelva la posición de la columna, entonces mandas el nombre de la tabla y la columna
//     let mut tabla_csv = String::from(tabla);
//     tabla_csv.push_str(".csv");
//     let mut h = String::new();
//     let mut leer = BufReader::new(fs::File::open(tabla_csv).expect("No se pudo abrir el archivo"));  // Elimina el manejo de error con `?`
//     leer.read_line(&mut h).expect("No se pudo leer la línea");  // Elimina el manejo de error con `?`

//     let header_vector: Vec<&str> = h.trim().split(",").collect();
//     let mut contador_aux = 0;
//     let mut contador_pos = 0;

//     for i in header_vector {
//         if i == columna {
//             contador_pos = contador_aux;
//         }
//         contador_aux += 1;
//     }
    
//     contador_pos
// }

// fn lector_arreglos(arreglo: Vec<&str>,tabla: String){
//     let mut contador = 0 ;
//     let lonngitud_arreglo = arreglo.len();
    
//     while contador != lonngitud_arreglo {
//         //para agarrar la columna lo paso a valor numerico asi no trabajo con el nombre
//         let mut clave = arreglo[contador];
//         let mut posicion = posicion_columna_csv(clave.to_string(), tabla);//deberia guardarce en un vec
//         //let posicion_limpia = posicion.remove("Ok","").remove("(","").remove(")");
//         println!("pos col: {:?}", posicion);
//         contador += 2; //para ir al valor
//     }
// }

// fn posicion_columna_csv(columna:String, tabla: String) -> io::Result<(usize)> {
//     //la idea en esta funcion es que devuelva la pos de la columna entonces mandas la pos en vez del nombre de la columna al hashmap 
//     let mut tabla_csv = String::from(tabla);
//     tabla_csv.push_str(".csv");
//     let mut h = String::new();
//     let mut leer = BufReader::new(fs::File::open(tabla_csv)?);
//     leer.read_line(&mut h)?;
//     let header_vector: Vec<&str> = h.trim().split(",").collect();
//     let mut contador_aux = 0;
//     let mut contador_pos = 0;
//     for i in header_vector{
//         if i.to_string() == columna{
//             contador_pos = contador_aux;
//         }
//         contador_aux += 1;
//     }
//     Ok(contador_pos)
// } 

fn main() {
    let terminal: Vec<String> = std::env::args().collect();
    let consulta_terminal = &terminal[2]; //consukta completa de SQL
    let mut consulta = consulta_terminal.replace(",", ""); //por ahora dsp borrar
    // let mut consulta = consulta_terminal
    //     .replace(",", "")
    //     .replace("\n", " ")
    //     .replace(";", "")
    //     .replace("(", "")
    //     .replace(")", "")
    //     .replace("=", "");

    let mut partes_consulta: Vec<&str> = consulta.trim().split_whitespace().collect(); // Divide la cadena en partes
    let instruccion = partes_consulta[0];
    partes_consulta.remove(0);


    if instruccion == "INSERT" {
        //INSERT INTO ordenes (id, id_cliente, producto, cantidad) VALUES (111, 6, 'Laptop', 3);
        let consulta_ref = &consulta;
        insert::comando_insert(consulta_ref.to_string());
        
    }

    if instruccion == "UPDATE" {


        let consulta_ref = &consulta;
        update::comando_update(consulta_ref.to_string());

    }
    if instruccion == "DELETE" {
        //DELETE FROM contact WHERE person_id IN (SELECT id FROM person WHERE  place_of_birth = 'San Francisco');
        //DELETE FROM person WHERE lastname = 'Burton';
        let consulta_ref = &consulta;
        delete::comando_delete(consulta_ref.to_string());

        
    }
    if instruccion == "SELECT" {
        

        let consulta_ref = &consulta;

        select::comando_select(consulta_ref.to_string());

        //let output_sleect = instruccion_select(consulta);
        /*let mut division_from: Vec<&str> = consulta.trim().split("FROM").collect(); // Divide la cadena en partes

        let mut previo_from = division_from[0];
        let mut posterior_from = division_from[1];
        let mut columnas_a_mostrar: Vec<&str> = previo_from.trim().split_whitespace().collect(); //guardo las columnas a mostrar
        columnas_a_mostrar.remove(0); //borro la instruccion
        println!("posterior_from:{}", posterior_from);

        if posterior_from.contains("WHERE") {
            let mut division_where: Vec<&str> = posterior_from.trim().split("WHERE").collect();
            let mut previo_where = division_where[0];
            println!("previo_where:{}", previo_where);
            let mut posterior_where_select = division_where[1];
            println!("posterior_where:{}", posterior_where_select);

            if posterior_where_select.contains("OR") {
                let mut division_or: Vec<&str> =
                    posterior_where_select.trim().split("OR").collect();
            }
            if posterior_where_select.contains("AND") {
                let mut division_and: Vec<&str> =
                    posterior_where_select.trim().split("AND").collect();
            }
        } */

        //let mut sql: InstruccionBuilder = InstruccionBuilder::new(partes_consulta[0].to_string(), partes_consulta[1].to_string(), partes_consulta[3].to_string());
        //let output = sql.select();

        //peracion.seleccionar(parts, result)
        //wtr.write_record(&["a", "b", "c", "d"]);
    }

    //wtr.flush();

    //let mut my_reader = result.unwrap();
    /*for record in my_reader.records(){
        let data = record.unwrap();
        let info: Info_tabla = Info_tabla::new(data.get(0).unwrap().to_string(), data.get(1).unwrap().to_string(), data.get(2).unwrap().to_string(), data.get(3).unwrap().to_string());

        println!("Your id is {} ", info.id);
        println!("Your id_cliente is {} ", info.id_cliente);
        println!("Your producto is {} ", info.producto);
        println!("Your cantidad is {} ", info.cantidad);

    }*/
}
